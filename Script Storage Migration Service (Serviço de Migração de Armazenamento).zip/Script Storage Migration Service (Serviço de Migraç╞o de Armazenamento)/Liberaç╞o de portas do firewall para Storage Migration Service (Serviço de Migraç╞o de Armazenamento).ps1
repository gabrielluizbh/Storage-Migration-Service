﻿# Script de crição de regras do firewall para utlização do Storage Migration Service (Serviço de Migração de Armazenamento) - Windows em Inglês e Português


# Servidor orquestrador - Windows Server 2019

Enable-NetFirewallRule -DisplayName "File and Printer Sharing (SMB-In)" # Inglês

Enable-NetFirewallRule -DisplayName "Compartilhamento de Arquivo e Impressora (SMB-Entrada)" # Português


# Servidor de origem e destino - Windows Server 2012, 2012 R2, 2016 e 2019


Enable-NetFirewallRule -DisplayName "File and Printer Sharing (SMB-In)" # Inglês

Enable-NetFirewallRule -DisplayName "Compartilhamento de Arquivo e Impressora (SMB-Entrada)" # Português


Enable-NetFirewallRule -DisplayName "Netlogon Service (NP-In)" # Inglês

Enable-NetFirewallRule -DisplayName "Serviço de Logon de Rede (NP-In)" # Português


Enable-NetFirewallRule -DisplayName "Windows Management Instrumentation (DCOM-In)" # Inglês

Enable-NetFirewallRule -DisplayName "Instrumentação de gerenciamento do Windows (DCOM-In)" # Português

Enable-NetFirewallRule -DisplayName "Windows Management Instrumentation (WMI-In)" # Inglês

Enable-NetFirewallRule -DisplayName "Instrumentação de gerenciamento do Windows (WMI-In)" # Português